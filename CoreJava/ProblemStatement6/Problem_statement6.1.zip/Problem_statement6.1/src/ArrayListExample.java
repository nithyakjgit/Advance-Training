import java.util.ArrayList;


public class ArrayListExample 
{
    public static void main(String[] args) 
    {
        ArrayList<String> list = new ArrayList<>(2);
         
        list.add("Amit");
        list.add("Arjun");
        list.add("Karthik");
        list.add("Darshan");
         
        System.out.println( list.contains("Amit") );       //true
         
        System.out.println( list.contains("akash") );       //false
    }
}
