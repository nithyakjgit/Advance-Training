
public class Token {
public static void main(String[] args) {
	String s1="23 + 45 - ( 343 / 12 )";
	
String[] w=s1.split("\\\s");
	
	for(String w1:w){  
		System.out.println(w1); 
		//System.out.println(" ");
	}
}
}
